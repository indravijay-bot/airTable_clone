import { z } from "zod";
import { TRPCError } from "@trpc/server";

import { createTRPCRouter, protectedProcedure } from "~/server/api/trpc";

export const tableRouter = createTRPCRouter({
  create: protectedProcedure
    .input(
      z.object({
        baseId: z.string(),
        name: z
          .string()
          .min(1, "Table name is required")
          .max(100, "Table name is too long"),
      }),
    )
    .mutation(async ({ ctx, input }) => {
      try {
        // Verify the base belongs to the user
        const base = await ctx.db.base.findFirst({
          where: {
            id: input.baseId,
            createdById: ctx.session.user.id,
          },
        });

        if (!base) {
          throw new TRPCError({
            code: "NOT_FOUND",
            message: "Base not found or you do not have permission",
          });
        }

        // Create table with default columns
        const table = await ctx.db.table.create({
          data: {
            name: input.name,
            base: {
              connect: {
                id: input.baseId, // connect the table to this base
              },
            },
            createdBy: {
              connect: { id: ctx.session.user.id },
            },

            columns: {
              createMany: {
                data: [
                  { name: "Name", type: "TEXT", order: 0 },
                  { name: "Amount", type: "NUMBER", order: 1 },
                ],
              },
            },
          },
        });

        // Import faker dynamically for server-side seeding
        const { faker } = await import("@faker-js/faker");

        // Create 10 rows for the table
        const rowsData = Array.from({ length: 10 }).map(() => ({
          tableId: table.id,
        }));
        await ctx.db.row.createMany({ data: rowsData });

        // Fetch rows and columns to create cells
        const createdRows = await ctx.db.row.findMany({
          where: { tableId: table.id },
        });
        const columns = await ctx.db.column.findMany({
          where: { tableId: table.id },
        });

        // Prepare cells data with faker values
        const cellsData = [];
        for (const row of createdRows) {
          for (const column of columns) {
            let value = "";
            if (column.type === "TEXT") value = faker.person.fullName();
            else if (column.type === "NUMBER")
              value = faker.number.int({ min: 0, max: 1000 }).toString();

            cellsData.push({
              rowId: row.id,
              columnId: column.id,
              value,
            });
          }
        }

        await ctx.db.cell.createMany({ data: cellsData });

        return table;
      } catch (error) {
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "Failed to create table",
          cause: error,
        });
      }
    }),

  getByBaseId: protectedProcedure
    .input(z.object({ baseId: z.string() }))
    .query(async ({ ctx, input }) => {
      try {
        // Verify the base belongs to the user
        const base = await ctx.db.base.findFirst({
          where: {
            id: input.baseId,
            createdById: ctx.session.user.id,
          },
        });

        if (!base) {
          throw new TRPCError({
            code: "NOT_FOUND",
            message: "Base not found or you do not have permission",
          });
        }

        // Fetch tables of that base ordered by creation date
        const tables = await ctx.db.table.findMany({
          where: { baseId: input.baseId },
          orderBy: { createdAt: "desc" },
        });

        return tables;
      } catch (error) {
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "Failed to fetch tables",
          cause: error,
        });
      }
    }),

  // Additional router methods like update, delete, pagination etc. can be added here
});
