export type Base = {
  id: string;
  name: string;
  description: string;
};

export type Table = {
  id: string;
  name: string;
};
