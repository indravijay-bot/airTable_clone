-- AlterTable
ALTER TABLE "Table" ADD COLUMN     "rowCount" INTEGER NOT NULL DEFAULT 0;
